# Command to start this application:

docker-compose up -d
